let dispatcher

function setDispatcher(_dispatcher) {
	dispatcher = _dispatcher
}

export {
	setDispatcher,
	dispatcher
}