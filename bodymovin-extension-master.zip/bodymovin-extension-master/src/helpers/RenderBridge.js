import csInterface from './CSInterfaceHelper'
import {dispatcher} from './storeDispatcher'
import actions from '../redux/actions/actionTypes'

csInterface.addEventListener('bm:render:start', function (ev) {
	if(ev.data) {
	} else {
	}
});

csInterface.addEventListener('bm:render:complete', function (ev) {
	if(ev.data) {
	} else {
	}
});

csInterface.addEventListener('bm:render:update', function (ev) {
	if(ev.data) {
	} else {
	}
});

csInterface.addEventListener('bm:render:fonts', function (ev) {
	if(ev.data) {
	} else {
	}
});


csInterface.addEventListener('bm:render:chars', function (ev) {
	if(ev.data) {
	} else {
	}
});

