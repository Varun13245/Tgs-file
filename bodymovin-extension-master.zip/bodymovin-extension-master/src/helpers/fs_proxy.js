function proxy_fs() {
	return window.__fs
}

module.exports = proxy_fs()