import {CSInterface} from './CSInterface'
var csInterface = new CSInterface();

export default csInterface