$.__bodymovin.layerTypes = {
	precomp : 0,
    solid : 1,
    still : 2,
    nullLayer : 3,
    shape : 4,
    text : 5,
    audio : 6,
    pholderVideo : 7,
    imageSeq : 8,
    video : 9,
    pholderStill : 10,
    guide : 11,
    adjustment : 12,
    camera : 13,
    light : 14
}